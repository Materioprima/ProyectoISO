/**
 * Test extensions specific to the JUnit Jupiter test engine.
 */

package org.junit.jupiter.engine.extension;
